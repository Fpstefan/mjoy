## mjoy
Subset of the Programming Language ***Joy*** with Turtle Graphics

![dracheimage](https://fpstefan.github.io/fpstefande/dracheimage.png)

\
***Look at***

---> [Dokumentation.pdf](https://github.com/Fpstefan/mjoy/blob/master/Dokumentation.pdf)\
---> [Referenz.pdf](https://github.com/Fpstefan/mjoy/blob/master/Referenz.pdf)\
---> [QuickStartGuide.pdf](https://github.com/Fpstefan/mjoy/blob/master/QuickStartGuide.pdf)\
---> [Get-It](https://www.heise.de/download/product/mjoy) ... (for Downloading Installer)


Licence of all sourcecode in this Repo is now: (CC BY 3.0) Fpstefan

